import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image, ImageTk, ImageDraw
import os
import pyttsx3
import threading
from drowsiness_detection import detect_drowsiness

def upload_image():
    file_path = filedialog.askopenfilename()
    if file_path:
        load_image(file_path)
        result = detect_drowsiness(file_path)
        result_label.config(text=f"{result}", font=("Helvetica", 20, "bold"))
        if result == "!!! You are in Drowsy Mode !!!":
            alarm()

def load_image(file_path):
    img = Image.open(file_path)
    img = img.resize((250, 250), Image.Resampling.LANCZOS)
    img = ImageTk.PhotoImage(img)
    panel.config(image=img)
    panel.image = img

def alarm():
    threading.Thread(target=speak, args=("Danger!  Danger!  Danger!  Drowsiness detected its danger! Please take a break.",)).start()
    messagebox.showwarning("Drowsiness Detected", "Drowsiness detected! Please take a break.")

def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def set_frame_background():
    frame.update_idletasks()  # Ensure the frame dimensions are updated
    frame_width = frame.winfo_width()
    frame_height = frame.winfo_height()
    
    frame_background_image = Image.open("frame_background.jpg")
    frame_background_image = frame_background_image.resize((frame_width, frame_height), Image.Resampling.LANCZOS)
    frame_background_image = ImageTk.PhotoImage(frame_background_image)
    
    frame_background_label.config(image=frame_background_image)
    frame_background_label.image = frame_background_image

def create_rounded_button_image(width, height, radius, color):
    image = Image.new("RGBA", (width, height), (255, 255, 255, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((0, 0, width, height), radius, fill=color)
    return ImageTk.PhotoImage(image)

# Create the main window
root = tk.Tk()
root.title("Drowsiness Detection System")
root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")

# Load and set background image
background_image = Image.open("background.jpg")
background_image = background_image.resize((root.winfo_screenwidth(), root.winfo_screenheight()), Image.Resampling.LANCZOS)
background_image = ImageTk.PhotoImage(background_image)

background_label = tk.Label(root, image=background_image)
background_label.place(relwidth=1, relheight=1)

# Create frame for content with transparent-like background b33c00
frame = tk.Frame(root, bg="#b33c00", bd=5)
frame.place(relx=0.5, rely=0.1, relwidth=0.60, relheight=0.6, anchor='n')

# Create label for the frame background image
frame_background_label = tk.Label(frame)
frame_background_label.place(relwidth=1, relheight=1)

#frame.tk_setPalette(background="#ff6600")

# Create rounded button image
rounded_button_image = create_rounded_button_image(200, 50, 20, "#ff4000")

# Create upload buttons and labels
panel = tk.Label(text="DRIVER DROWSINESS DETECTION",bg="YELLOW",fg="RED",font=("Comic Sans MS",20,"bold") )                 
panel.pack(pady=5)

upload_btn = tk.Button(frame, text="Upload Image", command=upload_image, font=("serif", 18,"bold"), fg="white", compound="center")
upload_btn.config(image=rounded_button_image, width=200, height=50, borderwidth=0, highlightthickness=0)
upload_btn.pack(pady=20)

panel = tk.Label(frame, text="Image Uploading!!! please wait",bg="blue",fg="white")
panel.pack(pady=10)

result_label = tk.Label(frame, text="Result: N/A", font=("Comic Sans MS", 20), bg='#000000', fg="yellow")
result_label.pack(pady=20)

# Update frame background after main loop starts
root.after(100, set_frame_background)

root.mainloop()