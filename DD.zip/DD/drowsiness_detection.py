import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import cv2
import mediapipe as mp
import numpy as np
from scipy.spatial import distance as dist

mp_face_mesh = mp.solutions.face_mesh

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def detect_drowsiness(image_path):
    EYE_AR_THRESH = 0.3

    frame = cv2.imread(image_path)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    with mp_face_mesh.FaceMesh(static_image_mode=True, max_num_faces=1, min_detection_confidence=0.5) as face_mesh:
        results = face_mesh.process(frame_rgb)
        
        if not results.multi_face_landmarks:
            return "No face detected"
        
        for face_landmarks in results.multi_face_landmarks:
            # Define landmark indices for the left and right eyes
            left_eye_indices = [33, 160, 158, 133, 153, 144]
            right_eye_indices = [362, 385, 387, 263, 373, 380]
            
            left_eye = np.array([(face_landmarks.landmark[i].x, face_landmarks.landmark[i].y) for i in left_eye_indices])
            right_eye = np.array([(face_landmarks.landmark[i].x, face_landmarks.landmark[i].y) for i in right_eye_indices])
            
            left_eye *= [frame.shape[1], frame.shape[0]]
            right_eye *= [frame.shape[1], frame.shape[0]]
            
            left_ear = eye_aspect_ratio(left_eye)
            right_ear = eye_aspect_ratio(right_eye)
            ear = (left_ear + right_ear) / 2.0

            print(f"Left EAR: {left_ear}, Right EAR: {right_ear}, Average EAR: {ear}")

            if ear < EYE_AR_THRESH:
                return "!!! You are in Drowsy Mode !!!"
            else:
                return "You are in Alert Mode"

    return "No face detected"
